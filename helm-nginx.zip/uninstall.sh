helm uninstall d7nginx
