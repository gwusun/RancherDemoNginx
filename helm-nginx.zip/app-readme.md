app readme.md

