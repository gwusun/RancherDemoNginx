helm install d7nginx .
